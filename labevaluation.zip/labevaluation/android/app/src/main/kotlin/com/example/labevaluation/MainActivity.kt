package com.example.labevaluation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
